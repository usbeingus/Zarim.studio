/**
 * ZARIM STUDIOS — Main JavaScript
 * Vanilla JS. Progressive enhancement. No frameworks.
 * Load with <script src="/js/main.js" defer> or relative path.
 */
(function () {
  'use strict';
  const cfg = window.ZARIM_CONFIG || {};
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Loading overlay ---------- */
  window.addEventListener('load', function () {
    const loader = document.querySelector('.loader');
    if (loader) setTimeout(() => loader.classList.add('is-hidden'), 300);
  });

  /* ---------- Header scroll state ---------- */
  const header = document.querySelector('.site-header');
  function updateHeader() {
    if (!header) return;
    header.classList.toggle('is-scrolled', window.scrollY > 20);
  }
  window.addEventListener('scroll', updateHeader, { passive: true });
  updateHeader();

  /* ---------- Mobile nav ---------- */
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.primary-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      const open = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!open));
      nav.classList.toggle('is-open', !open);
      document.body.style.overflow = !open ? 'hidden' : '';
    });
    nav.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        toggle.setAttribute('aria-expanded', 'false');
        nav.classList.remove('is-open');
        document.body.style.overflow = '';
      });
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && nav.classList.contains('is-open')) {
        toggle.click();
        toggle.focus();
      }
    });
  }

  /* ---------- Reveal on scroll ---------- */
  const revealEls = document.querySelectorAll('.reveal');
  if (revealEls.length && 'IntersectionObserver' in window && !reduced) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(en => {
        if (en.isIntersecting) {
          en.target.classList.add('is-visible');
          io.unobserve(en.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -60px 0px' });
    revealEls.forEach(el => io.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('is-visible'));
  }

  /* ---------- FAQ accordion ---------- */
  document.querySelectorAll('.faq-trigger').forEach(btn => {
    btn.addEventListener('click', () => {
      const panel = document.getElementById(btn.getAttribute('aria-controls'));
      const open = btn.getAttribute('aria-expanded') === 'true';
      // close others in same list
      const list = btn.closest('.faq-list');
      if (list) {
        list.querySelectorAll('.faq-trigger[aria-expanded="true"]').forEach(other => {
          if (other !== btn) {
            other.setAttribute('aria-expanded', 'false');
            const p = document.getElementById(other.getAttribute('aria-controls'));
            if (p) p.style.maxHeight = '0px';
          }
        });
      }
      btn.setAttribute('aria-expanded', String(!open));
      if (panel) panel.style.maxHeight = !open ? panel.scrollHeight + 'px' : '0px';
    });
  });

  /* ---------- Portfolio filter ---------- */
  const filterBtns = document.querySelectorAll('[data-filter]');
  const items = document.querySelectorAll('[data-industry]');
  if (filterBtns.length && items.length) {
    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const f = btn.dataset.filter;
        filterBtns.forEach(b => b.classList.remove('is-active'));
        btn.classList.add('is-active');
        items.forEach(item => {
          const match = f === 'all' || item.dataset.industry === f;
          item.style.display = match ? '' : 'none';
        });
      });
    });
  }

  /* ---------- Back to top ---------- */
  const toTop = document.querySelector('.to-top');
  if (toTop) {
    window.addEventListener('scroll', () => {
      toTop.classList.toggle('is-visible', window.scrollY > 600);
    }, { passive: true });
    toTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: reduced ? 'auto' : 'smooth' }));
  }

  /* ---------- Custom cursor (desktop only) ---------- */
  const fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  if (fine && !reduced) {
    const dot = document.createElement('div');
    dot.className = 'cursor-dot';
    dot.setAttribute('aria-hidden', 'true');
    document.body.appendChild(dot);
    let mx = 0, my = 0;
    document.addEventListener('mousemove', e => {
      mx = e.clientX; my = e.clientY;
      dot.style.transform = `translate(${mx}px, ${my}px) translate(-50%, -50%)`;
    });
    document.querySelectorAll('a, button, .card, .project-feature').forEach(el => {
      el.addEventListener('mouseenter', () => dot.classList.add('is-hover'));
      el.addEventListener('mouseleave', () => dot.classList.remove('is-hover'));
    });
  }

  /* ---------- Form handling ---------- */
  const forms = document.querySelectorAll('[data-zarim-form]');
  forms.forEach(form => {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const status = form.querySelector('.form-status');
      const submit = form.querySelector('button[type="submit"]');
      if (!validateForm(form)) return;

      const endpoint = cfg.formService && cfg.formService.endpoint;
      if (!endpoint) {
        if (status) {
          status.className = 'form-status is-error';
          status.textContent = 'This form is not yet connected. Please email us at ' + (cfg.contact?.email || 'usbeingusfr@gmail.com') + ' or message us on WhatsApp.';
        }
        return;
      }
      submit.disabled = true;
      submit.textContent = 'Sending…';
      try {
        const res = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Accept': 'application/json' },
          body: new FormData(form)
        });
        if (res.ok) {
          if (status) { status.className = 'form-status is-success'; status.textContent = 'Thank you. Your message has been sent.'; }
          form.reset();
        } else {
          throw new Error('Network response not ok');
        }
      } catch (err) {
        if (status) { status.className = 'form-status is-error'; status.textContent = 'Something went wrong. Please email us at ' + (cfg.contact?.email || 'usbeingusfr@gmail.com') + ' or message us on WhatsApp.'; }
      } finally {
        submit.disabled = false;
        submit.textContent = submit.dataset.label || 'Send enquiry';
      }
    });
  });

  function validateForm(form) {
    let ok = true;
    form.querySelectorAll('[required]').forEach(input => {
      const field = input.closest('.field');
      const err = field ? field.querySelector('.error') : null;
      if (!input.value.trim() || (input.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value))) {
        ok = false;
        if (field) field.classList.add('has-error');
        if (err) err.textContent = input.type === 'email' ? 'Please enter a valid email address.' : 'This field is required.';
      } else {
        if (field) field.classList.remove('has-error');
      }
    });
    return ok;
  }

  /* ---------- Populate dynamic contact links ---------- */
  document.querySelectorAll('[data-wa]').forEach(el => {
    const key = el.dataset.wa || 'general';
    const num = (cfg.contact && cfg.contact.whatsappNumber) || '919103173043';
    const msg = (cfg.contact && cfg.contact.whatsappMessages && cfg.contact.whatsappMessages[key]) || 'Hello ZARIM STUDIOS.';
    el.setAttribute('href', 'https://wa.me/' + num + '?text=' + encodeURIComponent(msg));
    el.setAttribute('target', '_blank');
    el.setAttribute('rel', 'noopener');
  });
  document.querySelectorAll('[data-email]').forEach(el => {
    const email = (cfg.contact && cfg.contact.email) || 'usbeingusfr@gmail.com';
    el.setAttribute('href', 'mailto:' + email);
  });

  /* ---------- Social links (hidden until real URLs) ---------- */
  document.querySelectorAll('[data-social]').forEach(el => {
    const key = el.dataset.social;
    const url = cfg.social && cfg.social[key];
    if (url) { el.setAttribute('href', url); el.setAttribute('target', '_blank'); el.setAttribute('rel', 'noopener'); el.hidden = false; }
    else { el.hidden = true; }
  });

  /* ---------- Current year ---------- */
  document.querySelectorAll('[data-year]').forEach(el => el.textContent = new Date().getFullYear());
})();