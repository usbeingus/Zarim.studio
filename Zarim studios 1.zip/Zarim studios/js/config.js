/**
 * ZARIM STUDIOS — Central Configuration
 * Edit only this file to update contact info, pricing, social links, form endpoint.
 */
window.ZARIM_CONFIG = {
  brand: {
    name: "ZARIM STUDIOS",
    tagline: "Building Digital Identities. Creating Digital Futures.",
    positioning: "Based in Kashmir. Serving businesses across India."
  },
  contact: {
    email: "usbeingusfr@gmail.com",
    whatsappNumber: "919103173043",
    whatsappDisplay: "+91 9103173043",
    whatsappMessages: {
      general: "Hello ZARIM STUDIOS, I'd like to discuss a project.",
      project: "Hello ZARIM STUDIOS, I'd like to discuss my project requirements.",
      quote: "Hello ZARIM STUDIOS, I'd like to request a quotation."
    }
  },
  social: {
    instagram: "",
    linkedin: ""
  },
  formService: {
    endpoint: "",
    fromEmail: "usbeingusfr@gmail.com"
  },
  domain: {
    canonical: "https://zarim.studio"
  },
  pricing: {
    starter: {
      name: "Starter",
      priceLabel: "Custom Quote",
      priceNote: "Pricing tailored to your requirements.",
      description: "A refined, single-purpose website for businesses establishing their presence online.",
      features: [
        "Up to 5 core pages",
        "Responsive design",
        "Contact form setup",
        "Foundational on-page SEO",
        "Basic performance optimisation",
        "Post-launch walkthrough"
      ]
    },
    professional: {
      name: "Professional",
      priceLabel: "Custom Quote",
      priceNote: "Pricing tailored to your requirements.",
      description: "A complete business website with stronger structure, storytelling and content depth.",
      features: [
        "Up to 10 pages",
        "Custom UI/UX design",
        "Content structuring assistance",
        "Foundational SEO + schema",
        "Google Search Console setup",
        "Basic page-speed optimisation",
        "30 days post-launch support"
      ],
      recommended: true
    },
    premium: {
      name: "Premium",
      priceLabel: "Custom Quote",
      priceNote: "Pricing tailored to your requirements.",
      description: "A bespoke digital experience for brands seeking exceptional design and functionality.",
      features: [
        "Unlimited-scope discussion",
        "Bespoke UI/UX and art direction",
        "Advanced interactions",
        "Custom functionality as scoped",
        "Foundation + local SEO",
        "Extended post-launch support",
        "Priority communication"
      ]
    }
  }
};